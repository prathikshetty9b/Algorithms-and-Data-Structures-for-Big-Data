#define INVALID -1
#define SIZE 15


int sum_of_n_mumbers_in_file(int n);
int find_square_and_write_to_file();
int store_n_numbers_in_reversed_order(int n);
int count_text_pattern(const char *my_string);
int length_of_each_line_in_file();
int pass_file(int n);
int rewrite_file(int n);
